---
layout: page
title: About me 
---

This is a static page. It could be an 'about page' if you'd like.
